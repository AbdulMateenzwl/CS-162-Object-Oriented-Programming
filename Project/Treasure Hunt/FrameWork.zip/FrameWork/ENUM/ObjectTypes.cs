﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameWork.ENUM
{
    public enum ObjectTypes
    {
        player,
        floor,
        Mainfloor,
        stairs,
        playerfire,
        enemy,
        enemyfire,
        otherobjects
    }
}
