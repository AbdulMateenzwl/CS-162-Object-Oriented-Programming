class Product:
    name=""
    price=0.0
    def __init__(self,name,price):
        self.name=name
        self.price=price